package cn.pxl.login.common.code;

public enum RedisKey {
    FourCd("0001","四位验证码");

    private String keyCode;
    private String keyDesc;

    RedisKey(String keyCode, String keyDesc) {
        this.keyCode = keyCode;
        this.keyDesc = keyDesc;
    }

    public String getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String keyCode) {
        this.keyCode = keyCode;
    }

    public String getKeyDesc() {
        return keyDesc;
    }

    public void setKeyDesc(String keyDesc) {
        this.keyDesc = keyDesc;
    }
}

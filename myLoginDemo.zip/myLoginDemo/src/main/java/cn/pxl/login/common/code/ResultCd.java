package cn.pxl.login.common.code;

public enum ResultCd {
    success("000000"),
    failed("111111");

    private String resultCd;

    ResultCd(String resultCd) {
        this.resultCd = resultCd;
    }

    public String getResultCd() {
        return resultCd;
    }

    public void setResultCd(String resultCd) {
        this.resultCd = resultCd;
    }
}

package cn.pxl.login.controller;

import cn.pxl.login.entity.User;
import cn.pxl.login.entity.common.RequestMessage;
import cn.pxl.login.entity.common.ResponseMessage;
import cn.pxl.login.entity.req.Step01Req;
import cn.pxl.login.entity.resp.Step01Resp;
import cn.pxl.login.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.List;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/findAll")
    public List<User> findAll(){
        return userService.findAll();
    }

    @RequestMapping("/findById")
    public User findById(Long id){
        return userService.findByUserId(id);
    }

    @RequestMapping("/findByName")
    public User findByName(String userName){
        return userService.findByUserName(userName);
    }

    //第一步：传入账户号，密码和验证码，需校验传入的账户号，密码是否正确。
    //判断方式：根据账户号，查询User表，获取其密码，与传入的密码进行比较，不一致则抛出异常。
    @PostMapping("/step01")
    public ResponseMessage<Step01Resp> step01(@RequestBody RequestMessage<Step01Req> req){
        return userService.step01(req);
    }


}

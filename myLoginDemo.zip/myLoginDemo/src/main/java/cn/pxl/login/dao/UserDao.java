package cn.pxl.login.dao;

import cn.pxl.login.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserDao {
    public List<User> findAll();
    public User findByUserName(String userName);
    public User findByUserId(Long id);
    public User findUserByUserAcctNbr(@Param("acctNbr") String acctNbr);
}

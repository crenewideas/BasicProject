package cn.pxl.login.entity.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RequestMessage <T> implements Serializable {

    private String txnCd;
    private T requestData;

}

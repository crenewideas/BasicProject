package cn.pxl.login.entity.common;

import cn.pxl.login.common.code.ResultCd;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.io.Serializable;
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ResponseMessage <T> implements Serializable {
    private static final String FAILED_MESSAGE = "请求失败！";
    private static final String SUCCESS_MESSAGE = "请求成功！";
    private String resultCode;
    private String resultMessage;
    private T data;

    public ResponseMessage(String resultCode, String resultMessage) {
        this.resultCode = resultCode;
        this.resultMessage = resultMessage;
    }

    public static ResponseMessage requestFailed(){
        return requestFailed(ResultCd.failed.getResultCd(),FAILED_MESSAGE);
    }

    public static ResponseMessage requestFailed(String failedMessage) {
        return requestFailed(ResultCd.failed.getResultCd(),failedMessage);
    }

    public static ResponseMessage requestFailed(String resultCd, String failedMessage) {
        return new ResponseMessage<>(resultCd,failedMessage);
    }

    public static ResponseMessage requestSuccess(Object resultData){
        return new ResponseMessage<>(ResultCd.success.getResultCd(),SUCCESS_MESSAGE,resultData);
    }

}

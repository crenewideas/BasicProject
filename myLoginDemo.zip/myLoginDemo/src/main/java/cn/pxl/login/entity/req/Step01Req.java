package cn.pxl.login.entity.req;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Step01Req implements Serializable {
    //账户号
    private String acctNbr;
    //密码
    private String passWord;
    //输入的验证码
    private String identifyCode;
    //生成的验证码
    private String createdIdentifyCode;
}

package cn.pxl.login.service;

import cn.pxl.login.entity.User;
import cn.pxl.login.entity.common.RequestMessage;
import cn.pxl.login.entity.common.ResponseMessage;
import cn.pxl.login.entity.req.Step01Req;
import cn.pxl.login.entity.resp.Step01Resp;

import java.util.List;

public interface UserService {
    public List<User> findAll();
    public User findByUserName(String userName);
    public User findByUserId(Long id);
    public User findUserByUserAcctNbr(String acctNbr);
    public ResponseMessage<Step01Resp> step01(RequestMessage<Step01Req> req);
}

package cn.pxl.login.service.impl;

import cn.pxl.login.common.code.RedisKey;
import cn.pxl.login.common.code.ResultCd;
import cn.pxl.login.common.utils.RedisUtil;
import cn.pxl.login.dao.UserDao;
import cn.pxl.login.entity.User;
import cn.pxl.login.entity.common.RequestMessage;
import cn.pxl.login.entity.common.ResponseMessage;
import cn.pxl.login.entity.req.Step01Req;
import cn.pxl.login.entity.resp.Step01Resp;
import cn.pxl.login.service.UserService;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;
    @Autowired
    private RedisUtil redisUtil;

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    public User findByUserName(String userName) {
        return userDao.findByUserName(userName);
    }

    @Override
    public User findByUserId(Long id) {
        return userDao.findByUserId(id);
    }

    @Override
    public User findUserByUserAcctNbr(String acctNbr) {
        return userDao.findUserByUserAcctNbr(acctNbr);
    }

    @Override
    public ResponseMessage<Step01Resp> step01(RequestMessage<Step01Req> req) {
        ResponseMessage<Step01Resp> respResponseMessage = new ResponseMessage<>();
        Step01Req requestData = req.getRequestData();
        String acctNbr = requestData.getAcctNbr();
        String identifyCode = requestData.getIdentifyCode();
        String beforePassWord = requestData.getPassWord();
        String createdIdentifyCode = requestData.getCreatedIdentifyCode();
        String message = "";
        if(StringUtils.isBlank(acctNbr)){
            message = "账户号不能为空！";
        }
        if(StringUtils.isBlank(identifyCode) || identifyCode.trim().length() != 4){
            message = "验证码不能为空，或验证码长度有误!";
        }
        if(StringUtils.isBlank(createdIdentifyCode) || createdIdentifyCode.trim().length() != 4){
            message = "生成验证码有误!";
        }
        if(StringUtils.isBlank(beforePassWord)){
            message = "密码不能为空!";
        }

        //校验验证码是否相同
        if (!StringUtils.equals(identifyCode.trim(),createdIdentifyCode.trim())){
            message = "验证码输入有误，请重新输入!";
        }
        //2.从Redis中校验验证码次数是否超限

        //以用户的账户号+rediskey作为key，查询获取redis中是否存在验证码。
        String key = acctNbr + RedisKey.FourCd.getKeyCode();
        Object redisKey = redisUtil.get(key);
        if(redisKey != null){
            message = "验证码信息尚未失效，请稍后再试!";
        } else {
            //将对应的key设置到redis中，指定失效时间为60秒
            redisUtil.expire(key,60L);
        }

        //3.根据传入的账户号查询第三方库，获取用户信息
        User userInfo = userDao.findUserByUserAcctNbr(acctNbr);
        if(userInfo == null){
            message = "该第三方用户信息不存在!";
        }

        if(StringUtils.isNotBlank(message)){
            return ResponseMessage.requestFailed(message);
        }
        //4.用户存在，那么比较账户密码与第三方库中的是否一致，不一致则返回异常信息。
        //validPassWord : 第三方库里存的密码，是加密的
        String validPassWord = userInfo.getPassWord();
        String encodingPassWord = DigestUtils.md5DigestAsHex(beforePassWord.getBytes(StandardCharsets.UTF_8));
        //123456 -> e10adc3949ba59abbe56e057f20f883e
        System.out.println("加密后的前端传入的密码是："+encodingPassWord);
        boolean equals = StringUtils.equals(encodingPassWord, validPassWord);
        if(!equals){
            message = "第三方密码不正确，请重新输入!";
        }
        //密码校验通过则返回成功信息。
        if(StringUtils.isNotBlank(message)){
            respResponseMessage = ResponseMessage.requestFailed(message);
        }else {
            Step01Resp step01Resp = new Step01Resp(ResultCd.success.getResultCd());
            respResponseMessage = ResponseMessage.requestSuccess(step01Resp);
        }
        return respResponseMessage;
    }

    //生成入参Json字符串
    public static void main(String[] args) {
        RequestMessage<Step01Req> step01ReqRequestMessage = new RequestMessage<>();
        step01ReqRequestMessage.setTxnCd("step01");
        Step01Req step01Req = new Step01Req();
        step01Req.setAcctNbr("123456");
        step01Req.setPassWord("123456");
        step01Req.setIdentifyCode("1234");
        step01Req.setCreatedIdentifyCode("1234");
        step01ReqRequestMessage.setRequestData(step01Req);
        String jsonString = JSONObject.toJSONString(step01ReqRequestMessage);
        System.out.println(jsonString);
    }
}
